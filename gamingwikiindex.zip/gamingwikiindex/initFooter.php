<?php

   echo "<div id='footer'>
			</div>
			</body>
			</html>"
?>