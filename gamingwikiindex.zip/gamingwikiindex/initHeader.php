
<?php

        echo "<header>
			<a href='https://webdev.cs.uwosh.edu/students/guang16/gamingwikiindex/home.php'>
			<img src='gamingwiki.png' alt='Gamingwiki Logo' width = '100' height = '100'/>
			</a>
    
			<a href='https://www.wikipedia.org/'>
			<img src='wikipedia.png' alt='wikipedia Logo'  width = '100' height = '100'/>
			</a>
    
			</header>
			<nav>
    
				<form action='search.php' method='post'>
					<input type='text' name='search' id='search' class='inNav' col='2' placeholder='          Custom Search'/>
				</form>
    
				<form action='signin.js' method='post'>
				<input type='submit' value='SIGNIN' class='inNav' id='signin'></button>
				</form>
        
				<form action='creataccount.html'>
				<input type='submit' value='SIGNUP' id='signup' class='inNav'></input>
				</form>   
			</nav>"			
?>